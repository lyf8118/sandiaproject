Serial Number

Edit usb_descriptors.a51 line 381-385 to change the serial number.