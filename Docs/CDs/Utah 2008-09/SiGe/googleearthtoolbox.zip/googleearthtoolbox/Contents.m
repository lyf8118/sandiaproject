%   Convert your MATLAB output to Google Earth format:
%      <a href="matlab:open_content_html">Google Earth Toolbox Contents</a>

