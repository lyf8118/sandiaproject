function demo_ge_cylinder()


x1 = -10;
y1 = -10;
x2 = -10.2;
y2 = -10.2;
x3 = -9.8;
y3 = -10;

output = ge_cylinder( x1, y1, 5000, 15000);

output2 = ge_cylinder( x2, y2, 5000, 20000, ...
                    'divisions', 3, ...
                    'name', 'Cylinder number 2, less divisions.', ...
                    'lineWidth',5.0, ...
                    'lineColor','b8200bff', ...
                    'polyColor','FF00FF00');
output3 = ge_cylinder( x3, y3, 5000, 25000, ...
                    'divisions', 5, ...
                    'visibility', 0 );

kmlFileName = 'demo_ge_cylinder.kml';
kmlTargetDir = [''];%..',filesep,'kml',filesep];

ge_output([kmlTargetDir,kmlFileName], [output output2 output3],...
                                                        'name',kmlFileName);