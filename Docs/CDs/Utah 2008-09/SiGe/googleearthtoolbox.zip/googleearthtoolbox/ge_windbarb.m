function kmlStr = ge_windbarb(X,Y,Z,U,V,varargin)
% % Reference page in help browser: 
% <a href="matlab:web(fullfile(ge_root,'html','ge_windbarb.html'),'-helpbrowser')">link</a> to html documentation
% <a href="matlab:web(fullfile(ge_root,'html','license.html'),'-helpbrowser')">show license statement</a> 
%

AuthorizedOptions = authoptions( mfilename );


%             id = 'windbarb';
%          idTag = 'id';
%           name = 'ge_windbarb';
%    description = '';
      timeStamp = ' ';
 timeSpanStart = ' ';
  timeSpanStop = ' ';
%     visibility = 1;
   msgToScreen = false;
%        Snippet = '';
%       altitude = 1.0;
%         extrude = 0
%     tessellate = 0;
  altitudeMode = 'relativeToGround';
  
  p=mfilename('fullpath');
[toolboxroot,fname,ext,vsn] = fileparts(p);
    clear fname ext vsn
    
rLink = '';

arrowScale = 1e5;

parsepairs %script that parses Parameter/Value pairs.

if msgToScreen
    disp(['Running: ',mfilename,'...'])
end

if numel(X)==0
    error(['Empty X-coordinates passed to ',mfilename]);
end
if numel(Y)==0
    error(['Empty Y-coordinates passed to ',mfilename]);
end
if numel(Z)==0
    error(['Empty Y-coordinates passed to ',mfilename]);
elseif numel(Z)==1
    Z=ones(size(X))*Z;
end


if numel(U)==0
    error(['Empty U-data passed to ',mfilename]);
end
if numel(V)==0
    error(['Empty V-data passed to ',mfilename]);
end
if ~isequal(numel(X),numel(Y),numel(U),numel(V))
    error(['Number of elements in input variables X,Y,U, and V must be the same (',mfilename,').'])
end

if ~(isequal(altitudeMode,'clampToGround')||...
   isequal(altitudeMode,'relativeToGround')||...
   isequal(altitudeMode,'absolute'))

    error(['Variable ',39,'altitudeMode',39, ' should be one of ' ,39,'clampToGround',39,', ',10,39,'relativeToGround',39,', or ',39,'absolute',39,'.' ])
end   

if strcmp(rLink,'')
elseif ~ismember(rLink(end),'\/')
    error(['Parameter ',39,'rLink',39,' should end in a folder separator',char(10),'character. See <a href="matlab:doc filesep">doc filesep</a>.'])
end
    

guestimation=525;
kmlStr=repmat('%',[1,guestimation*numel(X)]);
n=0;
    
for k=1:numel(X)
    
    if all(~isnan([X(k),Y(k),U(k),V(k)]))

        daeModelStr = [rLink,retrieve_barb(U(k),V(k),Y(k))];

        TMP = ge_quiver3(X(k),Y(k),Z(k),U(k)*-1.0,V(k)*-1.0,0,...
                                  'modelLinkStr',daeModelStr,...
                                  'altitudeMode',altitudeMode,...
                                    'arrowScale',arrowScale,...
                                 'name',['barb=&#0039;',daeModelStr,'&#0039;',],...
                              'fixedArrowLength',1,...
                                 'timeSpanStart',timeSpanStart,...
                                  'timeSpanStop',timeSpanStop,...
                                     'timeStamp',timeStamp);
        kmlStr(n+1:n+length(TMP))=TMP;
        n = n+length(TMP);
    end
end
kmlStr(n+1:end)='';


if msgToScreen
   disp(['Running ' mfilename '...Done']) 
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%             LOCAL FUNCTION STARTS HERE               %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function barbFileStr = retrieve_barb(U,V,Y)

Vk = V/0.51;
Uk = U/0.51;
speedKnots = sqrt(Uk.^2+Vk.^2);

if Y<0
    startIx=20;
else
    startIx=0;
end

daeCell = {'001nhemi00000025kts.dae';...
            '002nhemi00250075kts.dae';...
            '003nhemi00750125kts.dae';...
            '004nhemi01250175kts.dae';...
            '005nhemi01750225kts.dae';...
            '006nhemi02250275kts.dae';...
            '007nhemi02750325kts.dae';...
            '008nhemi03250375kts.dae';...
            '009nhemi03750425kts.dae';...
            '010nhemi04250475kts.dae';...
            '011nhemi04750525kts.dae';...
            '012nhemi05250575kts.dae';...
            '013nhemi05750625kts.dae';...
            '014nhemi06250675kts.dae';...
            '015nhemi06750725kts.dae';...
            '016nhemi07250775kts.dae';...
            '017nhemi07750825kts.dae';...
            '018nhemi08250875kts.dae';...
            '019nhemi08750925kts.dae';...
            '020nhemi09250975kts.dae';...
            '021shemi00000025kts.dae';...
            '022shemi00250075kts.dae';...
            '023shemi00750125kts.dae';...
            '024shemi01250175kts.dae';...
            '025shemi01750225kts.dae';...
            '026shemi02250275kts.dae';...
            '027shemi02750325kts.dae';...
            '028shemi03250375kts.dae';...
            '029shemi03750425kts.dae';...
            '030shemi04250475kts.dae';...
            '031shemi04750525kts.dae';...
            '032shemi05250575kts.dae';...
            '033shemi05750625kts.dae';...
            '034shemi06250675kts.dae';...
            '035shemi06750725kts.dae';...
            '036shemi07250775kts.dae';...
            '037shemi07750825kts.dae';...
            '038shemi08250875kts.dae';...
            '039shemi08750925kts.dae';...
            '040shemi09250975kts.dae'};

windSpeedBounds = [0,5,10:5:97.5];
d = windSpeedBounds-speedKnots;
f = find(min(abs(d))==abs(d));
barbFileStr = daeCell{startIx+f};

